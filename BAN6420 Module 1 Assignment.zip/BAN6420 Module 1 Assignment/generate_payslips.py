import random

# Constants
NUM_WORKERS = 400
GENDERS = ['Male', 'Female']

# Function to generate workers
def generate_workers(num):
    workers = []
    for i in range(0, num + 1):
        worker = {
            "id": i,
            "name": f"Worker_{i}",
            "gender": random.choice(GENDERS),
            "salary": random.randint(5000, 35000),
            "level": None
        }
        workers.append(worker)
    return workers

# Generate workers
workers = generate_workers(NUM_WORKERS)

# Generate payment slips with conditions and exception handling
for worker in workers:
    try:
        salary = worker['salary']
        gender = worker['gender']
        if 10000 < salary < 20000:
            worker['level'] = 'A1'
        if 7500 < salary < 30000 and gender == 'Female':
            worker['level'] = 'A5-F'
        print(f"Payment Slip - ID: {worker['id']}, Name: {worker['name']}, Gender: {gender}, Salary: ${salary}, Level: {worker['level']}")
    except Exception as e:
        print(f"Error generating payment slip for {worker['name']}: {e}")