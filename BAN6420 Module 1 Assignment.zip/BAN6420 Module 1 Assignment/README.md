# Worker Payment Slip Generator

This project generates payment slips for 400 dynamically created workers using both Python and R.

## Features

- Random generation of names, genders, and salaries
- Conditional logic for assigning employee levels
- Exception handling for potential errors
- Available in Python (`generate_payslips.py`) and R (`generate_payslips.R`)



## Requirements

- Python 3.13.3
- R version 4 or higher

