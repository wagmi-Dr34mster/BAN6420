set.seed(123)  # For reproducibility

NUM_WORKERS <- 400
genders <- c("Male", "Female")

# Generate workers
workers <- data.frame(
  id = 1:NUM_WORKERS,
  name = paste0("Worker_", 1:NUM_WORKERS),
  gender = sample(genders, NUM_WORKERS, replace = TRUE),
  salary = sample(5000:35000, NUM_WORKERS, replace = TRUE),
  level = NA
)

# Assign employee levels with error handling
for (i in 0:nrow(workers)) {
  tryCatch({
    salary <- workers$salary[i]
    gender <- workers$gender[i]
    if (salary > 10000 & salary < 20000) {
      workers$level[i] <- "A1"
    }
    if (salary > 7500 & salary < 30000 & gender == "Female") {
      workers$level[i] <- "A5-F"
    }
    cat(sprintf("Payment Slip - ID: %d, Name: %s, Gender: %s, Salary: $%d, Level: %s\n",
                workers$id[i], workers$name[i], gender, salary, workers$level[i]))
  }, error = function(e) {
    cat(sprintf("Error generating payment slip for Worker %d: %s\n", i, e$message))
  })
}